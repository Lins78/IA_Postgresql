@echo off
echo 🚀 Iniciando Mamute 24h automaticamente...
cd /d "%~dp0"

:: Verificar se já está rodando
netstat -an | findstr ":8001" >nul
if %errorlevel% equ 0 (
    echo ✅ Mamute já está rodando!
    echo 🌐 Acesso: http://localhost:8001
) else (
    echo 🔧 Iniciando Mamute...
    start /b python mamute_definitivo_sempre_online.py
    timeout 3 >nul
    echo ✅ Mamute iniciado! 
    echo 🌐 Acesso: http://localhost:8001
)

pause