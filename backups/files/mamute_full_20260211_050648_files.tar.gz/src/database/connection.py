"""
Gerenciador de conexão com PostgreSQL
"""
import psycopg2
from psycopg2.extras import RealDictCursor
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from contextlib import contextmanager
from typing import Dict, List, Any, Optional
import logging
import re

from ..utils.config import Config
from ..utils.logger import setup_logger

# Base para modelos SQLAlchemy
Base = declarative_base()

class DatabaseManager:
    """Gerenciador de conexão e operações com PostgreSQL"""
    
    def __init__(self, config: Config):
        """
        Inicializa o gerenciador de banco de dados
        
        Args:
            config: Instância da configuração
        """
        self.config = config
        self.logger = setup_logger(__name__, config.log_level)
        self.current_database = None
        
        # Configuração do SQLAlchemy
        self.engine = create_engine(
            config.database_url,
            echo=config.debug,
            pool_size=10,
            max_overflow=20
        )
        
        self.Session = sessionmaker(bind=self.engine)
        self.logger.info("Gerenciador de banco de dados inicializado")
        
        # Descobrir banco atual
        try:
            result = self.execute_query("SELECT current_database()")
            if result:
                self.current_database = result[0]['current_database']
        except:
            pass
    
    def test_connection(self) -> bool:
        """
        Testa a conexão com o banco de dados
        
        Returns:
            bool: True se a conexão for bem-sucedida
        """
        try:
            with self.engine.connect() as connection:
                from sqlalchemy import text
                result = connection.execute(text("SELECT 1"))
                self.logger.info("Conexão com PostgreSQL estabelecida com sucesso")
                return True
        except Exception as e:
            self.logger.error(f"Erro ao conectar com PostgreSQL: {e}")
            return False

    # ---------- Segurança SQL ----------
    @staticmethod
    def is_safe_select(query: str) -> bool:
        """Valida se a query é um SELECT seguro (sem DDL/DML perigosos)."""
        if not query:
            return False

        # Remover espaços e ponto e vírgula final
        query_clean = query.strip().rstrip(";")
        upper = query_clean.upper()

        # Permitir WITH ou SELECT apenas no início
        starts_with_select = upper.startswith("SELECT")
        starts_with_with = upper.startswith("WITH")
        if not (starts_with_select or starts_with_with):
            return False

        # Bloquear palavras perigosas comuns em DDL/DML/controle
        forbidden = [
            r"\\bINSERT\\b", r"\\bUPDATE\\b", r"\\bDELETE\\b", r"\\bDROP\\b",
            r"\\bALTER\\b", r"\\bCREATE\\b", r"\\bTRUNCATE\\b", r"\\bGRANT\\b",
            r"\\bREVOKE\\b", r"\\bCOPY\\b", r"\\bDO\\b", r"\\bBEGIN\\b",
            r"\\bCOMMIT\\b", r"\\bROLLBACK\\b"
        ]

        for pattern in forbidden:
            if re.search(pattern, upper, flags=re.IGNORECASE):
                return False

        # Evitar múltiplas instruções
        if ";" in query_clean:
            return False

        return True

    @staticmethod
    def assert_safe_select(query: str):
        """Lança exceção se a query não for um SELECT seguro."""
        if not DatabaseManager.is_safe_select(query):
            raise ValueError("Apenas consultas SELECT simples são permitidas para este endpoint.")
    
    @contextmanager
    def get_session(self):
        """
        Context manager para sessões do SQLAlchemy
        
        Yields:
            Session: Sessão do SQLAlchemy
        """
        session = self.Session()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            self.logger.error(f"Erro na sessão do banco: {e}")
            raise
        finally:
            session.close()
    
    def execute_query(self, query: str, params: Optional[Any] = None) -> List[Dict[str, Any]]:
        """Executa SELECT reutilizando pool do SQLAlchemy (raw psycopg2)."""
        try:
            with self.engine.raw_connection() as conn:
                with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                    cursor.execute(query, params or ())
                    rows = [dict(row) for row in cursor.fetchall()]
                    self.logger.debug(f"Query executada: {len(rows)} resultados")
                    return rows
        except Exception as e:
            self.logger.error(f"Erro ao executar query: {e}")
            raise
    
    def execute_command(self, command: str, params: Optional[Any] = None) -> int:
        """Executa INSERT/UPDATE/DELETE reutilizando pool do SQLAlchemy (raw psycopg2)."""
        try:
            with self.engine.raw_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(command, params or ())
                    affected_rows = cursor.rowcount or 0
                    conn.commit()
                    self.logger.debug(f"Comando executado: {affected_rows} linhas afetadas")
                    return affected_rows
        except Exception as e:
            self.logger.error(f"Erro ao executar comando: {e}")
            raise
    
    def create_tables(self):
        """Cria todas as tabelas definidas nos modelos"""
        try:
            Base.metadata.create_all(self.engine)
            self.logger.info("Tabelas criadas com sucesso")
        except Exception as e:
            self.logger.error(f"Erro ao criar tabelas: {e}")
            raise
    
    def get_table_info(self, table_name: str) -> List[Dict[str, Any]]:
        """
        Obtém informações sobre uma tabela
        
        Args:
            table_name: Nome da tabela
        
        Returns:
            List[Dict]: Informações das colunas
        """
        query = """
        SELECT 
            column_name,
            data_type,
            is_nullable,
            column_default
        FROM information_schema.columns 
        WHERE table_name = %(table_name)s
        ORDER BY ordinal_position
        """
        return self.execute_query(query, {"table_name": table_name})
    
    def get_all_tables(self) -> List[str]:
        """
        Obtém lista de todas as tabelas do banco
        
        Returns:
            List[str]: Lista com nomes das tabelas
        """
        query = """
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public'
        ORDER BY table_name
        """
        result = self.execute_query(query)
        return [row['table_name'] for row in result]
    
    def switch_database(self, database_name: str) -> bool:
        """
        Muda para um banco de dados específico
        
        Args:
            database_name: Nome do banco de dados
            
        Returns:
            bool: True se conseguiu mudar, False caso contrário
        """
        try:
            # Criar nova URL de conexão com o banco específico
            url_parts = self.config.database_url.split('/')
            new_url = '/'.join(url_parts[:-1]) + '/' + database_name
            
            # Criar novo engine
            new_engine = create_engine(
                new_url,
                echo=self.config.debug,
                pool_size=10,
                max_overflow=20
            )
            
            # Testar conexão
            with new_engine.connect() as conn:
                from sqlalchemy import text
                conn.execute(text("SELECT 1"))
            
            # Se chegou aqui, conexão é válida
            self.engine = new_engine
            self.Session = sessionmaker(bind=self.engine)
            self.current_database = database_name
            self.config.database_url = new_url
            
            self.logger.info(f"Mudou para banco de dados: {database_name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Erro ao mudar para banco {database_name}: {e}")
            return False
    
    def get_available_databases(self) -> List[str]:
        """
        Lista todos os bancos de dados disponíveis
        
        Returns:
            List[str]: Lista com nomes dos bancos
        """
        query = """
        SELECT datname 
        FROM pg_database 
        WHERE datistemplate = false 
        AND datname NOT IN ('postgres')
        ORDER BY datname
        """
        try:
            result = self.execute_query(query)
            return [row['datname'] for row in result]
        except Exception as e:
            self.logger.error(f"Erro ao listar bancos: {e}")
            return []